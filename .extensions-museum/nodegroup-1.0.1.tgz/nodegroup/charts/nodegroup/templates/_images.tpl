{{- define "common.image" -}}
{{- $registryName := .global.imageRegistry -}}
{{- $separator := ":" -}}
{{- $termination := .global.tag | toString -}}
{{- if .imageTag }}
    {{- $termination = .imageTag | toString -}}
{{- end -}}
{{- if $registryName }}
    {{- printf "%s/%s%s%s" $registryName .imageRepo $separator $termination -}}
{{- else -}}
    {{- printf "%s%s%s" .imageRepo $separator $termination -}}
{{- end -}}
{{- end -}}

{{- define "nodegroup.controller.image" -}}
{{ include "common.image" (dict "imageTag" .Values.image.nodegroup_controller_manager_tag "imageRepo" .Values.image.nodegroup_controller_manager_repo "global" .Values.global) }}
{{- end -}}

{{- define "nodegroup.apiserver.image" -}}
{{ include "common.image" (dict "imageTag" .Values.image.nodegroup_apiserver_tag "imageRepo" .Values.image.nodegroup_apiserver_repo "global" .Values.global) }}
{{- end -}}