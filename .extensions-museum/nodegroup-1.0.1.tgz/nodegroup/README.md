## Functionality

KubeSphere NodeGroup a UI management interface

## Installation

1. Go to the **KubeSphere Marketplace** page and find the **KubeSphere NodeGroup** extension. Click the **Install** button. Select the latest version and click the **Next** button.
2. On the **Extension Installation** tab, click and modify the **Extension Config** according to your needs. After configuring, click the **Start Installation** button to start the installation.
3. After the installation is complete, click the **Next** button to go to the cluster selection page. Check the clusters you want to install and click the **Next** button to go to the **Differential Configuration** page.
4. Update the **Differential Configuration** according to your needs. After updating, start the installation and wait for the installation to complete.

## Quick Start

After installation, you can make use of the extension on the following pages:

- Under the **Cluster Node** menu in the left navigation pane of the cluster, you will find **Node Group**.
- Menu **Node Groups** will be shown in the left navigation pane of the cluster.
- WHen creting workloads or jobs, in tab **Advanced Settings** ,choose **Select Nodes** and **Assigned by node group** , the **Node Group** selector will be shown.

## Uninstallation

Navigate to the **KubeSphere Marketplace** page, find the installed version of the **KubeSphere Network** extension, and click the **Uninstall** button to begin the uninstallation process.