## v1.0.1

### Bug Fixes

- Fix Prometheus report data containing special characters cannot be exported.

## 1.0.0

This is the first release of  [KubeEye](https://github.com/kubesphere-extensions/kubeeye). KubeEye is a cluster inspection tool that supports automated Kubernetes cluster checks using PromQL and OPA rules.