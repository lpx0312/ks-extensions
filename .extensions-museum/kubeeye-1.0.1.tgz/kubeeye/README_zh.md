KubeEye 是为 Kubernetes 设计的云原生集群巡检工具，用于根据自定义规则发现 Kubernetes 集群中存在的问题及风险。

### 使用
KubeEye 通过自定义规则发现 Kubernetes 集群中存在的问题及风险。并可以通过巡检计划定期自动执行巡检任务。

目前支持的规则类型有：
* OPA 规则
* PromQL 规则
* 文件变更规则
* 内核参数配置规则
* Systemd 服务状态规则
* 节点基本信息规则
* 文件内容检查规则
* 服务连通性检查规则

#### 导入规则
示例规则可参考 [kubeeye-rules](https://github.com/kubesphere/kubeeye/tree/release-1.0/sample/rules)

OPA 示例规则说明： 使用 [Rego](https://www.openpolicyagent.org/docs/latest/policy-language/) 语言编写，用于检查 Kubernetes 资源的配置是否符合预期。用于 KubeEye 规则编写时，请注意以下示例中注释的说明。

```yaml
apiVersion: kubeeye.kubesphere.io/v1alpha2
kind: InspectRule
metadata:
  name: deployment-inspect-rules
spec:
  opas:
    - name: imagePullPolicyRuleForDeployment
      rule: |-
        package inspect.kubeeye
        import rego.v1

        deny contains msg if {
          # 必须指定待检查资源的类型和版本
          input.kind == "Deployment"
          input.apiVersion == "apps/v1"

          level := "WARNING"

          container := input.spec.template.spec.containers[_]
          container.imagePullPolicy != "IfNotPresent"
          
          # 必须返回一个包含 Name, Namespace, Type, Message, Reason, Level 的结构体
          msg := {
              "Name": sprintf("%v", [input.metadata.name]),
              "Namespace": sprintf("%v", [input.metadata.namespace]),
              "Type": sprintf("%v", [input.kind]),
              "Message": "ControllersImagePullPolicyRule",
              "Reason": sprintf("当前资源镜像拉取策略为: %v , 需要修改为 IfNotPresent", [container.imagePullPolicy]),
              "Level": sprintf("%v", [level])
          }
        }
```
PromQL 规则示例说明：使用 [PromQL](https://prometheus.io/docs/prometheus/latest/querying/basics/) 语言编写，用于检查 Prometheus 监控指标是否符合预期。用于 KubeEye 规则编写时，请注意以下示例中注释的说明。

```yaml
apiVersion: kubeeye.kubesphere.io/v1alpha2
kind: InspectRule
metadata:
  name: promql-inspect-rules
spec:
  # 必须指定目标集群所使用的 Prometheus endpoint 地址
  prometheusEndpoint: http://prometheus-k8s.kubesphere-monitoring-system.svc.cluster.local:9090
  prometheus:
    - name: filesystem-less-20
      desc: Filesystem inode where less 20 %
      rule: (node_filesystem_files_free{fstype!="",job="node-exporter"} / node_filesystem_files{fstype!="",job="node-exporter"} * 100 < 20 and node_filesystem_readonly{fstype!="",job="node-exporter"} == 0)
    - name: NodeFilesystemSpaceFillingUp
      desc: Filesystem is predicted to run out of space within the next 24 hours.
      rule: (node_filesystem_avail_bytes{fstype!="",job="node-exporter"} / node_filesystem_size_bytes{fstype!="",job="node-exporter"} * 100 < 20 and predict_linear(node_filesystem_avail_bytes{fstype!="",job="node-exporter"}[6h], 24 * 60 * 60) < 0 and node_filesystem_readonly{fstype!="",job="node-exporter"} == 0)
    
```

#### 创建巡检计划
巡检计划中可设置巡检周期、历史保留数量以及指定巡检规则等，请按需配置巡检计划。
```shell
cat > plan.yaml << EOF
apiVersion: kubeeye.kubesphere.io/v1alpha2
kind: InspectPlan
metadata:
  name: inspectplan
spec:
  # 需要执行检查的计划时间，仅支持cron表达式，例："*/30 * * * ?"表示每30分钟执行一次巡检。
  # 如果仅需单次巡检，则将该参数移除。
  schedule: "*/30 * * * ?"
  # 巡检结果最大保留数量，不填写则是保留全部
  maxTasks: 10 
  # 是否暂停巡检计划, 仅作用于周期巡检，true 或 flase （默认false）
  suspend: false
  # 巡检超时时间, 默认 10m
  timeout: 10m
  # 巡检规则列表，用于关联对应的巡检规则，填写 inspectRule 名称
  # 可通过 kubectl get inspectrule 查看集群中巡检规则
  ruleNames:
  - name: configmap-inspect-rules
  - name: cronjob-inspect-rules
  - name: daemonset-inspect-rules
  - name: deployment-inspect-rules
  - name: event-inspect-rules
  - name: job-inspect-rules
  - name: node-inspect-rules
  - name: pod-inspect-rules
  - name: pod-state-inspect-rules
  # nodeName: master
  # nodeSelector:
  #   node-role.kubernetes.io/master: ""        
  # 多集群巡检（目前仅支持 KubeSphere 多集群巡检）
  # clusterName: 
  # - name: host
EOF


kubectl apply -f plan.yaml
```
