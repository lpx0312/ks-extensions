## v1.0.1

### Bug Fixes

- 修复 Prometheus 报表数据含有特殊字符时无法导出的问题。


## 1.0.0

这是 [KubeEye](https://github.com/kubesphere-extensions/kubeeye) 的首个扩展组件版本。KubeEye 是一款集群巡检工具，支持通过 PromQL 和 OPA 规则对 Kubernetes 集群进行自动化巡检与合规检查。