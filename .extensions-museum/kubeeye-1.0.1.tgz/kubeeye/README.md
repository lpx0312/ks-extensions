KubeEye is a cloud-native cluster inspection tool specifically designed for Kubernetes, capable of identifying issues and risks within the Kubernetes cluster based on custom rules.

### Usage

KubeEye inspects Kubernetes clusters based on custom rules to identify issues and risks. You can use KubeEye to automatically execute inspection tasks through inspection plans.

Supported Rules List
* OPA
* PromQL
* File Change
* Kernel Parameter Configuration
* Systemd Service Status
* Node Basic Info
* File Content Inspection
* Service Connectivity

#### Import Inspect Rules

The sample rules can be found at [kubeeye-rules](https://github.com/kubesphere/kubeeye/tree/release-1.0/sample/rules)

OPA rules are written in [Rego](https://www.openpolicyagent.org/docs/latest/policy-language/) language to check whether the configuration of Kubernetes resources meets expectations. When writing KubeEye rules, please pay attention to the comments in the following examples.

```yaml
apiVersion: kubeeye.kubesphere.io/v1alpha2
kind: InspectRule
metadata:
  name: deployment-inspect-rules
spec:
  opas:
    - name: imagePullPolicyRuleForDeployment
      rule: |-
        package inspect.kubeeye
        import rego.v1

        deny contains msg if {
          # Must specify the kind and version of the resource to be checked
          input.kind == "Deployment"
          input.apiVersion == "apps/v1"

          level := "WARNING"

          container := input.spec.template.spec.containers[_]
          container.imagePullPolicy != "IfNotPresent"
          
          # Must return a struct containing Name, Namespace, Type, Message, Reason, Level
          msg := {
              "Name": sprintf("%v", [input.metadata.name]),
              "Namespace": sprintf("%v", [input.metadata.namespace]),
              "Type": sprintf("%v", [input.kind]),
              "Message": "ControllersImagePullPolicyRule",
              "Reason": sprintf("Current resource image pull policy is: %v, need to be modified to IfNotPresent", [container.imagePullPolicy]),
              "Level": sprintf("%v", [level])
          }
        }
```
PromQL rules are written in [PromQL](https://prometheus.io/docs/prometheus/latest/querying/basics/) language to check whether Prometheus monitoring metrics meet expectations. When writing KubeEye rules, please pay attention to the comments in the following examples.

```yaml
apiVersion: kubeeye.kubesphere.io/v1alpha2
kind: InspectRule
metadata:
  name: promql-inspect-rules
spec:
  # Must specify the target cluster's Prometheus endpoint address
  prometheusEndpoint: http://prometheus-k8s.kubesphere-monitoring-system.svc.cluster.local:9090
  prometheus:
    - name: filesystem-less-20
      desc: Filesystem inode where less 20 %
      rule: (node_filesystem_files_free{fstype!="",job="node-exporter"} / node_filesystem_files{fstype!="",job="node-exporter"} * 100 < 20 and node_filesystem_readonly{fstype!="",job="node-exporter"} == 0)
    - name: NodeFilesystemSpaceFillingUp
      desc: Filesystem is predicted to run out of space within the next 24 hours.
      rule: (node_filesystem_avail_bytes{fstype!="",job="node-exporter"} / node_filesystem_size_bytes{fstype!="",job="node-exporter"} * 100 < 20 and predict_linear(node_filesystem_avail_bytes{fstype!="",job="node-exporter"}[6h], 24 * 60 * 60) < 0 and node_filesystem_readonly{fstype!="",job="node-exporter"} == 0)
    
```

#### Create Inspect Plan

Configure inspection plans on demand.
```shell
cat > plan.yaml << EOF
apiVersion: kubeeye.kubesphere.io/v1alpha2
kind: InspectPlan
metadata:
  name: inspectplan
spec:
  # The planned time for executing inspections only supports cron expressions. For example, '*/30 * * * ?' means that the inspection will be performed every 30 minutes.'
  # If only a single inspection is required, then remove this parameter.
  schedule: "*/30 * * * ?"
  # The maximum number of retained inspection results, if not filled in, will retain all.
  maxTasks: 10 
  # Should the inspection plan be paused, applicable only to periodic inspections, true or false (default is false).
  suspend: false
  # Inspection timeout, default 10 minutes.
  timeout: 10m
  # Inspection rule list, used to associate corresponding inspection rules, please fill in the inspectRule name.
  # Execute `kubectl get inspectrule` to view the inspection rules in the cluster.
  ruleNames:
    - name: inspect-rule-filter-file
    - name: inspect-rule-node-info
    - name: inspect-rule-node
    - name: inspect-rule-sbnormalpodstatus 
    - name: inspect-rule-deployment
    - name: inspect-rule-sysctl
    - name: inspect-rule-prometheus
    - name: inspect-rule-filechange
    - name: inspect-rule-systemd
  # nodeName: master
  # nodeSelector:
  #   node-role.kubernetes.io/master: ""        
  # Multi-cluster inspection (currently only supports multi-cluster inspection in KubeSphere)
  # clusterName: 
  # - name: host
EOF


kubectl apply -f plan.yaml
```
## Supported Rules List
* OPA
* PromQL
* File Change
* Kernel Parameter Configuration
* Systemd Service Status
* Node Basic Info
* File Content Inspection
* Service Connectivity
