## Functionality

KubeSphere NodeGroup is a core functional component specifically designed to simplify the management of Kubernetes cluster nodes. Through an intuitive graphical interface, it enables administrators to flexibly organize and label large numbers of heterogeneous nodes within a cluster based on hardware attributes, business roles, or environmental logic. This node grouping capability serves as the cornerstone for resource pooling management. By integrating scattered node resources into logically unified resource pools, it provides upper-layer applications with a clearer and more efficient view of resources and scheduling strategies. Consequently, it significantly enhances the operational management efficiency, resource utilization, and policy execution consistency of large-scale clusters.

## Installation

1. On the **Extensions Center** page, click **KubeSphere NodeGroup**, then click **Install**.
2. Select the latest version and modify the **Extension Config** as needed.
3. After configuration, click the **Start Installation** button and wait for the installation to complete.
4. On the **Clusters Selection** page, select the clusters where the Agent needs to be installed.
5. On the **Diff Config** tab, edit **Cluster Agent Config** as needed, then click **OK** to start installing the cluster Agent.

## Quick Start

After installation, you can make use of the extension on the following pages:

- The **Cluster Nodes** list under the **Nodes** menu in the cluster left navigation pane will display the **Node Group** column.
- The **Node Groups** menu will be shown in the left navigation pane of the cluster.
- When creating workloads or jobs, in the **Advanced Settings** tab, choose **Select Nodes** and **Assigned by node group**, the **Node Group** selector will be shown.

## Configuration

NodeGroup includes many features to support various scenarios. To accommodate different requirements, some features can be configured through an external file to control NodeGroup's functionality and logic.

Currently, the features are divided into three categories:

1. **Scheduling**: This configuration determines on which nodes pods should run after a node group is selected during deployment. Currently, this is achieved by using taints and tolerations to control the scheduling scope. The main configurations are as follows:

   a. **Scheduling Strategy**: This strategy determines on which nodes workloads should run when no node group is selected during deployment. Currently, there are three scenarios:
   
      - **all**: All nodes can be scheduled
      - **assigned**: Pods can only run in node groups associated with the current namespace
      - **unassigned**: Pods can only run on nodes that are not assigned to any node group

   b. **Ignore System Namespaces**: In edge cluster environments, we stipulate that workloads can only run in non-system namespaces. However, in regular KubeSphere clusters, this restriction is not always necessary. Therefore, this limitation is a configurable option.

   c. **Tolerate Edge Nodes**: Edge nodes have a taint by default that prevents workload scheduling. In edge cluster environments, we typically tolerate this taint. However, in regular KubeSphere clusters, this toleration is not very useful. Therefore, this is a configurable option.

   d. **Auto-taint Nodes**: After a node joins a node group, to prevent other workloads from being scheduled to the current node group, a taint can be added to the node to prevent other workloads from being scheduled. This is also a configurable option.

2. **Permissions**: Only users with corresponding cluster permissions can use this feature.

3. **Nodes**: Mainly refers to the node unbinding strategy, which determines whether nodes can be unbound directly or only after cleaning up resources.

Example Configuration:
```yaml
scheduling:
  policy: "all"
  ignoreSystemNamespace: true
  tolerateEdgeNode: true
  autoTaint: true
```

## Uninstallation

On the **Extensions Center** page, find **KubeSphere NodeGroup**, select the installed version, click the **Uninstall** button to start the uninstallation process.
